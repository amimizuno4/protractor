/* eslint-disable no-invalid-this */
import { After, Before, Status } from 'cucumber';
import { browser } from 'protractor';

Before(async (scenario) => {
    console.log('--Start of the Scenario--' + scenario.pickle.name);
    await browser.manage().window().maximize();
    await browser.manage().deleteAllCookies();
    await browser.manage().timeouts().pageLoadTimeout(30000);
    await browser.manage().timeouts().implicitlyWait(10000);
});

After(async (scenario) => {
    const scenarioName = scenario.pickle.name;
    console.log('--End of Scenario--' + scenarioName);
    if (scenario.result.status === Status.FAILED) {
        const screenshot = await browser.takeScreenshot();
        await this.attach(screenshot, 'image/png');
        console.log('End of Test');
    }
});
