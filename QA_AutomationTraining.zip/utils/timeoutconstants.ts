/* eslint-disable no-unused-vars */
export enum TimeOutConstants {

    xtraSmallWaitTime= 500,
    smallWaitTime= 1000,
    mediumWaitTime= 3000,
    largeWaitTime= 5000,
    xtraLargeWaitTime= 9000,

}
