// Follow Cucumber 4 format
import * as chai from 'chai';
import { Then } from 'cucumber';
import { Offers } from './offers.page';
import { browser, ExpectedConditions } from 'protractor';
import { TimeOutConstants } from '../../utils/timeoutconstants';
const expect = chai.expect;
const objOffers = new Offers();

Then('I should see {string} text on the Offers page', async (expectedText: string) => {
    await browser.driver.sleep(3000);
    await browser.wait(ExpectedConditions.presenceOf(objOffers.offfersAndPromotionsLabel), TimeOutConstants.largeWaitTime);
    const offersAndPromotionsText = await objOffers.offfersAndPromotionsLabel.getText();
    expect(expectedText).equals(offersAndPromotionsText);
});
