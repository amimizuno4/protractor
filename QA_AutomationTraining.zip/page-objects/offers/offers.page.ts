// eslint-disable-next-line no-unused-vars
import { by, element, ElementFinder } from 'protractor';


export class Offers {
     offfersAndPromotionsLabel: ElementFinder;

     constructor() {
         this.offfersAndPromotionsLabel = element(by.xpath('.//h1'));
     }
};
