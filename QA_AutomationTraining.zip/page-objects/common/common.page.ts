// eslint-disable-next-line no-unused-vars
import { element, ElementFinder, by } from 'protractor';

export class Common {
    homePageLinks: ElementFinder;


    public async clickLink( linksLabel: string ) {
        this.homePageLinks = element( by.xpath( '//a[@title=\'' + linksLabel + '\']' ) );
        return await this.homePageLinks.click();
    }
};
