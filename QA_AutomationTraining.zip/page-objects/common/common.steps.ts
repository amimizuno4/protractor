// Follow Cucumber 4 format
import { Common } from './common.page';
import * as chai from 'chai';
import { Given, When } from 'cucumber';
import { browser } from 'protractor';
const expect = chai.expect;
const objCommon = new Common;

Given( 'That I\'m on Servus.ca homepage', async () => {
    console.log( 'Navigate to Servus Ca page: ' + browser.params.baseurl );
    await browser.waitForAngularEnabled( false );
    await browser.get( browser.params.baseurl );
    console.log( 'Start to wait 5 secs' );
    await browser.driver.sleep(5000 );
    const url = await browser.getCurrentUrl();
    console.log( 'Current Url: ' + browser.params.baseurl );
    expect( url ).to.contains( browser.params.baseurl );
    console.log( 'On servus ca  Home Page' );
} );

When( 'I click on {string}', async ( linkName ) => {
    await browser.driver.sleep( 2000 );
    await objCommon.clickLink( linkName );
    console.log( 'User clicked on ' + linkName );
    await browser.driver.sleep( 1000 );
} );

