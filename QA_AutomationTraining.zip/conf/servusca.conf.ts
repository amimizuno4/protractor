// eslint-disable-next-line no-unused-vars
import { browser, Config } from 'protractor';

export const config: Config = {
    // seleniumAddress: 'http://localhost:4444/wd/hub',
    seleniumAddress: 'http://10.96.195.93:4444/wd/hub',


    // Timeouts
    allScriptsTimeout: 250000,
    getPageTimeout: 650000,
    directConnect: true,
    restartBrowserBetweenTests: false,
    ignoreUncaughtExceptions: true, // Do not completely terminate process when exceptions encountered

    // You could set no globals to true to avoid jQuery '$' and protractor '$' collisions on the global namespace.
    // eslint-disable-next-line max-len
    noGlobals: false, // However, this is required to be false in order to avoid issues with Node_Modules - See: "ReferenceError: browser is not defined when using protractor with typescript"

    params: {

        // Prod url - https://www.servus.ca/
        // Test url - https://publicsite-qa-sc91-cd.azurewebsites.net/
        baseurl: 'https://www.servus.ca/',
    },

    capabilities: {
        'browserName': 'chrome',
        'shardTestFiles': true,
        'maxInstances': 1,
        'chromeOptions': {
            useAutomationExtension: false,
            args: [
                '--no-sandbox',
                '--test-type=browser',
                '--allow-insecure-localhost',
                '--disable-infobars',

            ],
        },

    },

    // When running individual tests files
    // specs: ['../features/*.feature'],

    suites: {
        ServusCa: [

            '../../features/offers.feature',

        ],
    },

    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    cucumberOpts: {
        require: [
            // Experiences
            '../page-objects/Common/*.js',
            '../page-objects/offers/*.js',

            // Common Steps/Functions
            '../utils/hooks/*.js',
        ],
        tags: [
            '@regression',

        ],
        format: 'json:test-reports/results.json',
    },

    plugins: [
        {
            package: require.resolve('protractor-multiple-cucumber-html-reporter-plugin'),
            options: {
                automaticallyGenerateReport: true,
                removeExistingJsonReportFile: true,
                removeOriginalJsonReportFile: true,
                displayDuration: true,
            },
        },
    ],

    beforeLaunch: () => {

    },

    onPrepare: () => {
        browser.ignoreSynchronization = false; // Might not be required
    },

    onComplete: () => {
    // TODO
    },

    onCleanUp: (exitCode) => {
    // TODO
    },

    afterLaunch: () => {
    // TODO
    },
};
