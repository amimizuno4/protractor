# Introduction 
The purpose of this repo is to provide a space for training.

Here you can practice concepts around Git usage and store any temporary learning projects.

This repo is not considered a permanent storage space and everything here should be considered disposable for training purposes.