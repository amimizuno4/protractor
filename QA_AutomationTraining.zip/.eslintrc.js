module.exports = {
    'env': {
        'browser': true,
        'es6': true,
        'node': true,
    },
    'extends': [
        'google',
    ],
    'globals': {
        'Atomics': 'readonly',
        'SharedArrayBuffer': 'readonly',
    },
    'parser': '@typescript-eslint/parser',
    'parserOptions': {
        'ecmaVersion': 2018,
        'sourceType': 'module',
    },
    'plugins': [
        '@typescript-eslint',
    ],
    'rules': {
        'max-len': ['error', 170],
        'indent': ['error', 4, { 'SwitchCase': 1 }],
        'no-multi-spaces': 2,
        'no-multiple-empty-lines': [2, { 'max': 2 }],
        'linebreak-style': 0,
        'object-curly-spacing': ['error', 'always'],
        'padded-blocks': [1, 'always'],
        'camelcase': [2, { 'properties': 'always' }],
        'new-cap': ['error', { 'capIsNewExceptions': ['Before', 'After', 'Given', 'When', 'Then'] }],
        'no-var': 0,
        'no-array-constructor': 'warn',
        'require-jsdoc': [2, {
            'require': {
                'FunctionDeclaration': false,
                'MethodDefinition': false,
                'ClassDeclaration': false,
                'ArrowFunctionExpression': false,
                'FunctionExpression': false,
            },
        }],
    },
};
